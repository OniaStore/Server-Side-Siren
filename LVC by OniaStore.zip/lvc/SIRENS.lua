RequestScriptAudioBank("DLC_WMSIRENS\\SIRENPACK_ONE", false)

SIRENS = {	
	--[[1]]  { Name = "Police Nationale",   	String = "SIREN_ALPHA", 	Ref = "DLC_WMSIRENS_SOUNDSET" }, 
	--[[2]]  { Name = "Gendarmerie Nationale",  String = "SIREN_BRAVO", 	Ref = "DLC_WMSIRENS_SOUNDSET" }, 
	--[[3]]  { Name = "Sapeurs pompiers", 		String = "SIREN_CHARLIE", 	Ref = "DLC_WMSIRENS_SOUNDSET" }, 
    --[[4]]  { Name = "Pneumatique SP", 		String = "SIREN_DELTA", 	Ref = "DLC_WMSIRENS_SOUNDSET" }, 
	--[[5]]  { Name = "Samu", 	            	String = "SIREN_ECHO", 	    Ref = "DLC_WMSIRENS_SOUNDSET" }, 
	--[[6]]  { Name = "3 tons", 	        	String = "SIREN_FOXTROT", 	Ref = "DLC_WMSIRENS_SOUNDSET" }, 
	--[[7]]  { Name = "Americaine", 	    	String = "SIREN_GOLF", 	    Ref = "DLC_WMSIRENS_SOUNDSET" }, 
	--[[8]]  { Name = "Americaine 2", 	    	String = "SIREN_HOTEL", 	Ref = "DLC_WMSIRENS_SOUNDSET" }, 
}

SIREN_ASSIGNMENTS = {
	--['<gameName>'] = {0,tones 1,tones 2}, LE GAMENAME EST DISPONIBLE DANS LE VEHICLE.META
	['DEFAULT'] = {0,1,3},
	['50082021pn'] = {0,1,3},
	['POLICE'] = {0,1,6},
	['POLICE2'] = {0,2,3},
	['FIRETRUK'] = {0,3,4},
	['AMBULAN'] = {0,5,6} -- NE PAS REMPLACER PAR "AMBULANCE" CAR LE GAMENAME DE l'AMBULANCE PAR DEFAUT EST "AMBULAN"
}

-- ATTETION NE PAS TOUCHER A LA VALEUR 0